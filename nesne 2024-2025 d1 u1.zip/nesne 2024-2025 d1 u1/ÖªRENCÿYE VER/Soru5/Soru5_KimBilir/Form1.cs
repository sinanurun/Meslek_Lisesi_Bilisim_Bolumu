namespace Soru5_KimBilir
{
    public partial class Form1 : Form
    {
        int soruNo = 0;
        char dogruCevap = 'A';
        int dogruSay = 0;
        int yanlisSay = 0;

        public Form1()
        {
            InitializeComponent();
            SoruGoster();
        }

        void SonrakiSoruyaGec()
        {

            soruNo++;
            if (soruNo > 9)
            {
                soruNo = 0;
                lblDogruSay.Text = "0";
                lblYanlisSay.Text = "0";
            }

            lblSoruNo.Text = (soruNo + 1) + "/10";

            SoruGoster();

        }

        bool BittiMi()
        {
            if(soruNo == 9)
            {
                lblPuan.Text = $"{Convert.ToInt32(lblDogruSay.Text) * 10} Puan";
                pnlBitti.Visible = true;
                btnDevam.Text = "Yeniden Oyna";
                return true;
            }

            return false;
        }

        void SoruGoster()
        {
            pnlBitti.Visible = false;

            lblCevapA.BackColor = lblCevapB.BackColor = lblCevapC.BackColor = lblCevapD.BackColor = Color.Gainsboro;
            lblCevapA.Enabled = lblCevapB.Enabled = lblCevapC.Enabled = lblCevapD.Enabled = true;
            if (soruNo == 0)
            {
                lblSoru.Text = "Hangisi bir programlama dilidir?";
                lblCevapA.Text = "Lara";
                lblCevapB.Text = "K++";
                lblCevapC.Text = "C#";
                lblCevapD.Text = "CsGo";
                dogruCevap = 'C';
            }
            else if (soruNo == 1)
            {
                lblSoru.Text = "Hangisi bir tam say� de�i�ken t�r�d�r?";
                lblCevapA.Text = "int";
                lblCevapB.Text = "double";
                lblCevapC.Text = "bool";
                lblCevapD.Text = "float";
                dogruCevap = 'A';
            }
            else if (soruNo == 2)
            {
                lblSoru.Text = "Hangisi bir de�i�kenin de�erini 2 art�r�r?";
                lblCevapA.Text = "a=2";
                lblCevapB.Text = "a++";
                lblCevapC.Text = "++a";
                lblCevapD.Text = "a+=2";
                dogruCevap = 'D';
            }
            else if (soruNo == 3)
            {
                lblSoru.Text = "Hangisi metin girmek i�in kullan�lan kontrold�r?";
                lblCevapA.Text = "Label";
                lblCevapB.Text = "TextBox";
                lblCevapC.Text = "Button";
                lblCevapD.Text = "PictureBox";
                dogruCevap = 'B';
            }
            else if (soruNo == 4)
            {
                lblSoru.Text = "Hangisi bir kontrol�n yaz� rengini de�i�tirir?";
                lblCevapA.Text = "FontColor";
                lblCevapB.Text = "Color";
                lblCevapC.Text = "ForeColor";
                lblCevapD.Text = "BackColor";
                dogruCevap = 'C';
            }
            else if (soruNo == 5)
            {
                lblSoru.Text = "Hangisi bir kontrol�n metin hizalamas�n� ayarlar?";
                lblCevapA.Text = "TextAlign";
                lblCevapB.Text = "Text";
                lblCevapC.Text = "Name";
                lblCevapD.Text = "Dock";
                dogruCevap = 'A';
            }
            else if (soruNo == 6)
            {
                lblSoru.Text = "Hangisi bir resim g�stermek i�in kullan�lan kontrold�r?";
                lblCevapA.Text = "Label";
                lblCevapB.Text = "ListBox";
                lblCevapC.Text = "Menu";
                lblCevapD.Text = "PictureBox";
                dogruCevap = 'D';
            }
            else if (soruNo == 7)
            {
                lblSoru.Text = "Hangisi zamanlama kullanmak i�in kullan�lan komponenttir?";
                lblCevapA.Text = "FontDialog";
                lblCevapB.Text = "Timer";
                lblCevapC.Text = "Form";
                lblCevapD.Text = "Style";
                dogruCevap = 'B';
            }
            else if (soruNo == 8)
            {
                lblSoru.Text = "Hangisi bir kontrol� g�r�nmez yapar?";
                lblCevapA.Text = "Enabled = false";
                lblCevapB.Text = "Name = false";
                lblCevapC.Text = "Text = false";
                lblCevapD.Text = "Visible = false";
                dogruCevap = 'D';
            }
            else if (soruNo == 9)
            {
                lblSoru.Text = "Kendinizi nas�l hissediyorsunuz?";
                lblCevapA.Text = "�yi";
                lblCevapB.Text = "K�t�";
                lblCevapC.Text = "Ne �yi, Ne K�t�";
                lblCevapD.Text = "Berbat";
                dogruCevap = 'A';
            }
        }

        void DurumGuncelle()
        {
            lblDogruSay.Text = dogruSay.ToString();
            lblYanlisSay.Text = yanlisSay.ToString();
        }

        private void btnDevam_Click(object sender, EventArgs e)
        {
            if (pnlBitti.Visible)
            {
                soruNo = 0;
                pnlBitti.Visible = false;
                SoruGoster();

            }
            else
            {
                if (!BittiMi())
                {
                    SonrakiSoruyaGec();
                }
            }
        }
        private void lblCevapA_Click(object sender, EventArgs e)
        {
            if(dogruCevap == 'A')
            {
                lblCevapA.BackColor = Color.DarkSeaGreen;
                dogruSay++;
            }
            else
            {
                lblCevapA.BackColor = Color.Tomato;
                yanlisSay++;

                if (dogruCevap == 'B') lblCevapB.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'C') lblCevapC.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'D') lblCevapD.BackColor = Color.Goldenrod;
            }

            lblCevapA.Enabled = lblCevapB.Enabled = lblCevapC.Enabled = lblCevapD.Enabled = false;
            DurumGuncelle();
        }
        private void lblCevapB_Click(object sender, EventArgs e)
        {
            if (dogruCevap == 'B')
            {
                lblCevapB.BackColor = Color.DarkSeaGreen;
                dogruSay++;
            }
            else
            {
                lblCevapB.BackColor = Color.Tomato;
                yanlisSay++;

                if (dogruCevap == 'A') lblCevapA.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'C') lblCevapC.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'D') lblCevapD.BackColor = Color.Goldenrod;
            }

            lblCevapA.Enabled = lblCevapB.Enabled = lblCevapC.Enabled = lblCevapD.Enabled = false;
            DurumGuncelle();
        }
        private void lblCevapC_Click(object sender, EventArgs e)
        {
            if (dogruCevap == 'C')
            {
                lblCevapC.BackColor = Color.DarkSeaGreen;
                dogruSay++;
            }
            else
            {
                lblCevapC.BackColor = Color.Tomato;
                yanlisSay++;

                if (dogruCevap == 'A') lblCevapA.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'B') lblCevapB.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'D') lblCevapD.BackColor = Color.Goldenrod;
            }

            lblCevapA.Enabled = lblCevapB.Enabled = lblCevapC.Enabled = lblCevapD.Enabled = false;
            DurumGuncelle();
        }
        private void lblCevapD_Click(object sender, EventArgs e)
        {
            if (dogruCevap == 'D')
            {
                lblCevapD.BackColor = Color.DarkSeaGreen;
                dogruSay++;
            }
            else
            {
                lblCevapD.BackColor = Color.Tomato;
                yanlisSay++;

                if (dogruCevap == 'A') lblCevapA.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'B') lblCevapB.BackColor = Color.Goldenrod;
                else if (dogruCevap == 'C') lblCevapC.BackColor = Color.Goldenrod;
            }

            lblCevapA.Enabled = lblCevapB.Enabled = lblCevapC.Enabled = lblCevapD.Enabled = false;
            DurumGuncelle();
        }
    }
}
