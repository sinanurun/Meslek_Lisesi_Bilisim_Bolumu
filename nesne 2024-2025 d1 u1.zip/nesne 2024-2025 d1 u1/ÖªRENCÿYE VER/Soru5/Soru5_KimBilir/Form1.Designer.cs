﻿namespace Soru5_KimBilir
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            lblBaslik = new Label();
            label2 = new Label();
            lblYanlisSay = new Label();
            lblSoruNo = new Label();
            lblDogruSay = new Label();
            label6 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            panel6 = new Panel();
            lblCevapD = new Label();
            lblCevapB = new Label();
            lblCevapC = new Label();
            lblCevapA = new Label();
            panel7 = new Panel();
            panel3 = new Panel();
            btnDevam = new Button();
            panel4 = new Panel();
            pnlBitti = new Panel();
            lblPuan = new Label();
            label3 = new Label();
            lblSoru = new Label();
            panel5 = new Panel();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            pnlBitti.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(lblBaslik);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(lblYanlisSay);
            panel1.Controls.Add(lblSoruNo);
            panel1.Controls.Add(lblDogruSay);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 3, 4, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(574, 96);
            panel1.TabIndex = 0;
            // 
            // lblBaslik
            // 
            lblBaslik.AutoSize = true;
            lblBaslik.Font = new Font("Microsoft Sans Serif", 26F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblBaslik.ForeColor = Color.FromArgb(0, 192, 192);
            lblBaslik.Location = new Point(4, 9);
            lblBaslik.Margin = new Padding(4, 0, 4, 0);
            lblBaslik.Name = "lblBaslik";
            lblBaslik.Size = new Size(165, 39);
            lblBaslik.TabIndex = 1;
            lblBaslik.Text = "Kim Bilir?";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label2.ForeColor = Color.OrangeRed;
            label2.Location = new Point(498, 37);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(60, 24);
            label2.TabIndex = 0;
            label2.Text = "Yanlış";
            // 
            // lblYanlisSay
            // 
            lblYanlisSay.BackColor = Color.OrangeRed;
            lblYanlisSay.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblYanlisSay.ForeColor = Color.White;
            lblYanlisSay.Location = new Point(498, 66);
            lblYanlisSay.Margin = new Padding(4, 0, 4, 0);
            lblYanlisSay.Name = "lblYanlisSay";
            lblYanlisSay.Size = new Size(72, 28);
            lblYanlisSay.TabIndex = 0;
            lblYanlisSay.Text = "0";
            lblYanlisSay.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblSoruNo
            // 
            lblSoruNo.BackColor = Color.DeepSkyBlue;
            lblSoruNo.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblSoruNo.ForeColor = Color.White;
            lblSoruNo.Location = new Point(69, 66);
            lblSoruNo.Margin = new Padding(4, 0, 4, 0);
            lblSoruNo.Name = "lblSoruNo";
            lblSoruNo.Size = new Size(72, 28);
            lblSoruNo.TabIndex = 0;
            lblSoruNo.Text = "1/10";
            lblSoruNo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblDogruSay
            // 
            lblDogruSay.BackColor = Color.LimeGreen;
            lblDogruSay.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblDogruSay.ForeColor = Color.White;
            lblDogruSay.Location = new Point(387, 66);
            lblDogruSay.Margin = new Padding(4, 0, 4, 0);
            lblDogruSay.Name = "lblDogruSay";
            lblDogruSay.Size = new Size(72, 28);
            lblDogruSay.TabIndex = 0;
            lblDogruSay.Text = "0";
            lblDogruSay.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label6.ForeColor = Color.LightSkyBlue;
            label6.Location = new Point(4, 66);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(50, 24);
            label6.TabIndex = 0;
            label6.Text = "Soru";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.LimeGreen;
            label1.Location = new Point(387, 35);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(62, 24);
            label1.TabIndex = 0;
            label1.Text = "Doğru";
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(panel6);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 311);
            panel2.Margin = new Padding(4, 3, 4, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(574, 128);
            panel2.TabIndex = 1;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(lblCevapD);
            panel6.Controls.Add(lblCevapB);
            panel6.Controls.Add(lblCevapC);
            panel6.Controls.Add(lblCevapA);
            panel6.Controls.Add(panel7);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(0, 0);
            panel6.Margin = new Padding(4, 3, 4, 3);
            panel6.Name = "panel6";
            panel6.Size = new Size(574, 128);
            panel6.TabIndex = 2;
            // 
            // lblCevapD
            // 
            lblCevapD.BackColor = Color.FromArgb(224, 224, 224);
            lblCevapD.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblCevapD.Location = new Point(335, 72);
            lblCevapD.Margin = new Padding(4, 0, 4, 0);
            lblCevapD.Name = "lblCevapD";
            lblCevapD.Size = new Size(225, 36);
            lblCevapD.TabIndex = 1;
            lblCevapD.Text = "Cevap4";
            lblCevapD.TextAlign = ContentAlignment.MiddleLeft;
            lblCevapD.Click += lblCevapD_Click;
            // 
            // lblCevapB
            // 
            lblCevapB.BackColor = Color.FromArgb(224, 224, 224);
            lblCevapB.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblCevapB.Location = new Point(335, 14);
            lblCevapB.Margin = new Padding(4, 0, 4, 0);
            lblCevapB.Name = "lblCevapB";
            lblCevapB.Size = new Size(225, 36);
            lblCevapB.TabIndex = 1;
            lblCevapB.Text = "Cevap2";
            lblCevapB.TextAlign = ContentAlignment.MiddleLeft;
            lblCevapB.Click += lblCevapB_Click;
            // 
            // lblCevapC
            // 
            lblCevapC.BackColor = Color.FromArgb(224, 224, 224);
            lblCevapC.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblCevapC.Location = new Point(20, 72);
            lblCevapC.Margin = new Padding(4, 0, 4, 0);
            lblCevapC.Name = "lblCevapC";
            lblCevapC.Size = new Size(225, 36);
            lblCevapC.TabIndex = 1;
            lblCevapC.Text = "Cevap3";
            lblCevapC.TextAlign = ContentAlignment.MiddleLeft;
            lblCevapC.Click += lblCevapC_Click;
            // 
            // lblCevapA
            // 
            lblCevapA.BackColor = Color.FromArgb(224, 224, 224);
            lblCevapA.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblCevapA.Location = new Point(20, 14);
            lblCevapA.Margin = new Padding(4, 0, 4, 0);
            lblCevapA.Name = "lblCevapA";
            lblCevapA.Size = new Size(225, 36);
            lblCevapA.TabIndex = 1;
            lblCevapA.Text = "Cevap1";
            lblCevapA.TextAlign = ContentAlignment.MiddleLeft;
            lblCevapA.Click += lblCevapA_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.LightBlue;
            panel7.Dock = DockStyle.Top;
            panel7.Location = new Point(0, 0);
            panel7.Margin = new Padding(4, 3, 4, 3);
            panel7.Name = "panel7";
            panel7.Size = new Size(574, 6);
            panel7.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(btnDevam);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 439);
            panel3.Margin = new Padding(4, 3, 4, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(574, 53);
            panel3.TabIndex = 2;
            // 
            // btnDevam
            // 
            btnDevam.BackColor = Color.LightSkyBlue;
            btnDevam.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            btnDevam.ForeColor = Color.SteelBlue;
            btnDevam.Location = new Point(190, 8);
            btnDevam.Margin = new Padding(4, 3, 4, 3);
            btnDevam.Name = "btnDevam";
            btnDevam.Size = new Size(182, 42);
            btnDevam.TabIndex = 0;
            btnDevam.Text = "Devam Et";
            btnDevam.UseVisualStyleBackColor = false;
            btnDevam.Click += btnDevam_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(pnlBitti);
            panel4.Controls.Add(lblSoru);
            panel4.Controls.Add(panel5);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(0, 96);
            panel4.Margin = new Padding(4, 3, 4, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(574, 396);
            panel4.TabIndex = 1;
            // 
            // pnlBitti
            // 
            pnlBitti.Controls.Add(lblPuan);
            pnlBitti.Controls.Add(label3);
            pnlBitti.Location = new Point(157, 73);
            pnlBitti.Margin = new Padding(4, 3, 4, 3);
            pnlBitti.Name = "pnlBitti";
            pnlBitti.Size = new Size(267, 112);
            pnlBitti.TabIndex = 2;
            // 
            // lblPuan
            // 
            lblPuan.Font = new Font("Microsoft Sans Serif", 30F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPuan.ForeColor = Color.FromArgb(0, 192, 0);
            lblPuan.Location = new Point(4, 50);
            lblPuan.Margin = new Padding(4, 0, 4, 0);
            lblPuan.Name = "lblPuan";
            lblPuan.Size = new Size(259, 54);
            lblPuan.TabIndex = 0;
            lblPuan.Text = "100 Puan";
            lblPuan.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Red;
            label3.Location = new Point(68, 9);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(142, 31);
            label3.TabIndex = 0;
            label3.Text = "Oyun Bitti";
            // 
            // lblSoru
            // 
            lblSoru.Dock = DockStyle.Fill;
            lblSoru.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblSoru.ForeColor = Color.DeepSkyBlue;
            lblSoru.Location = new Point(0, 6);
            lblSoru.Margin = new Padding(4, 0, 4, 0);
            lblSoru.Name = "lblSoru";
            lblSoru.Padding = new Padding(12);
            lblSoru.Size = new Size(574, 390);
            lblSoru.TabIndex = 1;
            lblSoru.Text = "Hangisi bir programlama dilidir?";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(64, 64, 64);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Margin = new Padding(4, 3, 4, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(574, 6);
            panel5.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(574, 492);
            Controls.Add(panel2);
            Controls.Add(panel3);
            Controls.Add(panel4);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Kim Bilir?";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            pnlBitti.ResumeLayout(false);
            pnlBitti.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblYanlisSay;
        private System.Windows.Forms.Label lblSoruNo;
        private System.Windows.Forms.Label lblDogruSay;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblCevapD;
        private System.Windows.Forms.Label lblCevapB;
        private System.Windows.Forms.Label lblCevapC;
        private System.Windows.Forms.Label lblCevapA;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDevam;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblSoru;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblBaslik;
        private System.Windows.Forms.Panel pnlBitti;
        private System.Windows.Forms.Label lblPuan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
    }
}
